
<p align="center"><a href="https://misaraadel.github.io/village_diet/" target="_blank"><img src="https://misaraadel.github.io/village_diet/assets/images/logo/logo.svg" width="400"></a></p>

Design Made by [Misara Hammed](https://github.com/misaraadel)

----------

# Village Diet project

# with peekssolutions team 

- [Misara Adel](https://github.com/misaraadel)
- [Live Site](https://misaraadel.github.io/village_diet/)

For detailed explanation on how things work, contact me  <a href="https://api.whatsapp.com/send?phone=201007425819"><img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" style=" object-fit: contain;margin-left: 10px;" width="30px" height="30px" /></a> .


## Made with ♥ By

<p align="center"><a href="https://github.com/misaraadel" target="_blank"><img src="https://avatars.githubusercontent.com/u/41232116?v=4" width="200"></a></p>


## thank you ♥

<p align="center"><a href="https://github.com/misaraadel" target="_blank"><img src="https://github.com/misaraadel/sonbola/blob/main/misara_logo.svg" width="200"></a></p>